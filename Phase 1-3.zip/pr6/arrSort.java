package pr6;


import java.util.Arrays;

public class arrSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ar[] = {6,15,7,8,1,30};
		// Sort the array 
		Arrays.sort(ar);
		System.out.println(ar[3]);
	}

}
