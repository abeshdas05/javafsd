package pr6;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class QueueExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Queue<Integer> queue = new LinkedList<>();

        System.out.println("Queue Operations:");
        System.out.println("1. Add element to the queue");
        System.out.println("2. Remove element from the queue");
        System.out.println("3. Peek at the element at the front of the queue");
        System.out.println("4. Print the contents of the queue");
        System.out.println("5. Exit");

        while (true) {
            System.out.print("Enter operation number: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter element to add: ");
                    int element = scanner.nextInt();
                    queue.add(element);
                    System.out.println("Element " + element + " added to the queue");
                    break;

                case 2:
                    if (queue.isEmpty()) {
                        System.out.println("Queue is empty, cannot remove element");
                    } else {
                        int removedElement = queue.remove();
                        System.out.println("Element " + removedElement + " removed from the queue");
                    }
                    break;

                case 3:
                    if (queue.isEmpty()) {
                        System.out.println("Queue is empty, cannot peek at element");
                    } else {
                        int peekedElement = queue.peek();
                        System.out.println("Element at the front of the queue: " + peekedElement);
                    }
                    break;

                case 4:
                    System.out.println("Contents of the queue: " + queue);
                    break;

                case 5:
                    System.out.println("Exiting program...");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice, please try again");
                    break;
            }
        }
    }
}

