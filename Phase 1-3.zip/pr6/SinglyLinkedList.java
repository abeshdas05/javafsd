package pr6;

public class SinglyLinkedList {
    private Node head;

    private class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public void deleteKey(int key) {
        Node temp = head;
        Node prev = null;

        // if the key is found at the head
        if (temp != null && temp.data == key) {
            head = temp.next;
            return;
        }

        // search for the key and keep track of the previous node
        while (temp != null && temp.data != key) {
            prev = temp;
            temp = temp.next;
        }

        // if the key is not found
        if (temp == null) {
            return;
        }

        // unlink the node with the key
        prev.next = temp.next;
    }

    public void addNode(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node temp = head;
        while (temp.next != null) {
            temp = temp.next;
        }

        temp.next = newNode;
    }

    public void printList() {
        Node temp = head;

        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();

        // add nodes to the list
        list.addNode(1);
        list.addNode(2);
        list.addNode(3);
        list.addNode(4);
        list.addNode(5);

        System.out.println("Original list:");
        list.printList();

        // delete the first occurrence of key=3
        list.deleteKey(3);

        System.out.println("List after deleting the first occurrence of key=3:");
        list.printList();
    }
}
