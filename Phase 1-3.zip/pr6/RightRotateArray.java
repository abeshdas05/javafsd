package pr6;

import java.util.Arrays;

public class RightRotateArray {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        int[] rotatedArray = rightRotateArray(arr, 5);

        System.out.println("Original array: " + Arrays.toString(arr));
        System.out.println("Array after right rotation: " + Arrays.toString(rotatedArray));
    }

    public static int[] rightRotateArray(int[] arr, int k) {
        int n = arr.length;

        // create a new array to store the rotated elements
        int[] rotatedArray = new int[n];

        // copy the last k elements of the original array to the beginning of the rotated array
        for (int i = 0; i < k; i++) {
            rotatedArray[i] = arr[n-k+i];
        }

        // copy the first n-k elements of the original array to the end of the rotated array
        for (int i = k; i < n; i++) {
            rotatedArray[i] = arr[i-k];
        }

        return rotatedArray;
    }
}

