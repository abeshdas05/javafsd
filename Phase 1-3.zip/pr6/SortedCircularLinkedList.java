package pr6;

public class SortedCircularLinkedList {
    private Node head;

    private class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            newNode.next = head;
            return;
        }

        Node current = head;

        // find the node after which the new node should be inserted
        while (current.next != head && current.next.data < data) {
            current = current.next;
        }

        // insert the new node
        newNode.next = current.next;
        current.next = newNode;
    }

    public void printList() {
        if (head == null) {
            return;
        }

        Node current = head;

        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
    }

    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();

        // add nodes to the list
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(40);
        list.insert(25);

        System.out.println("Sorted circular linked list:");
        list.printList();
    }
}
