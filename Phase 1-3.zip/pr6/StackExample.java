package pr6;
import java.util.Scanner;
import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Stack<Integer> stack = new Stack<>();

        System.out.println("Stack Operations:");
        System.out.println("1. Push element onto the stack");
        System.out.println("2. Pop element from the stack");
        System.out.println("3. Peek at the top element of the stack");
        System.out.println("4. Print the contents of the stack");
        System.out.println("5. Exit");

        while (true) {
            System.out.print("Enter operation number: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter element to push onto stack: ");
                    int element = scanner.nextInt();
                    stack.push(element);
                    System.out.println("Element " + element + " pushed onto stack");
                    break;

                case 2:
                    if (stack.isEmpty()) {
                        System.out.println("Stack is empty, cannot pop element");
                    } else {
                        int poppedElement = stack.pop();
                        System.out.println("Element " + poppedElement + " popped from stack");
                    }
                    break;

                case 3:
                    if (stack.isEmpty()) {
                        System.out.println("Stack is empty, cannot peek at top element");
                    } else {
                        int topElement = stack.peek();
                        System.out.println("Top element of stack: " + topElement);
                    }
                    break;

                case 4:
                    System.out.println("Contents of the stack: " + stack);
                    break;

                case 5:
                    System.out.println("Exiting program...");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice, please try again");
                    break;
            }
        }
    }
}

